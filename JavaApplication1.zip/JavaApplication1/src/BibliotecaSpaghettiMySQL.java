import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class BibliotecaSpaghettiMySQL extends JFrame {

    // Componentes Swing (variables globales, mala práctica)
    JTextField txtId = new JTextField();
    JTextField txtTitulo = new JTextField();
    JTextField txtAutor = new JTextField();
    JTextArea areaLibros = new JTextArea();

    // Datos de conexión (hardcodeados aquí)
    String url = "jdbc:mysql://localhost:3306/biblioteca";
    String user = "root";          // Cambia por tu usuario
    String password = "";   // Cambia por tu password

    public BibliotecaSpaghettiMySQL() {
        setTitle("Biblioteca Spaghetti MySQL");
        setSize(450, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

        JLabel lblId = new JLabel("ID:");
        lblId.setBounds(10, 10, 80, 25);
        add(lblId);
        txtId.setBounds(100, 10, 200, 25);
        add(txtId);

        JLabel lblTitulo = new JLabel("Título:");
        lblTitulo.setBounds(10, 40, 80, 25);
        add(lblTitulo);
        txtTitulo.setBounds(100, 40, 200, 25);
        add(txtTitulo);

        JLabel lblAutor = new JLabel("Autor:");
        lblAutor.setBounds(10, 70, 80, 25);
        add(lblAutor);
        txtAutor.setBounds(100, 70, 200, 25);
        add(txtAutor);

        JButton btnCrear = new JButton("Crear");
        btnCrear.setBounds(10, 110, 80, 25);
        add(btnCrear);

        JButton btnLeer = new JButton("Leer");
        btnLeer.setBounds(100, 110, 80, 25);
        add(btnLeer);

        JButton btnActualizar = new JButton("Actualizar");
        btnActualizar.setBounds(190, 110, 100, 25);
        add(btnActualizar);

        JButton btnEliminar = new JButton("Eliminar");
        btnEliminar.setBounds(300, 110, 90, 25);
        add(btnEliminar);

        areaLibros.setBounds(10, 150, 400, 200);
        areaLibros.setEditable(false);
        add(areaLibros);

        // Listeners con lógica SQL mezclada (mala práctica)

        btnCrear.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Connection con = DriverManager.getConnection(url, user, password);
                    PreparedStatement ps = con.prepareStatement("INSERT INTO Libro (id, titulo, autor) VALUES (?, ?, ?)");
                    ps.setInt(1, Integer.parseInt(txtId.getText()));
                    ps.setString(2, txtTitulo.getText());
                    ps.setString(3, txtAutor.getText());
                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Libro creado");
                    ps.close();
                    con.close();
                    limpiarCampos();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Error al crear libro: " + ex.getMessage());
                }
            }
        });

        btnLeer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Connection con = DriverManager.getConnection(url, user, password);
                    Statement st = con.createStatement();
                    ResultSet rs = st.executeQuery("SELECT * FROM Libro");
                    areaLibros.setText("");
                    while (rs.next()) {
                        areaLibros.append("ID: " + rs.getInt("id") + ", Título: " + rs.getString("titulo") + ", Autor: " + rs.getString("autor") + "\n");
                    }
                    rs.close();
                    st.close();
                    con.close();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Error al leer libros: " + ex.getMessage());
                }
            }
        });

        btnActualizar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Connection con = DriverManager.getConnection(url, user, password);
                    PreparedStatement ps = con.prepareStatement("UPDATE Libro SET titulo=?, autor=? WHERE id=?");
                    ps.setString(1, txtTitulo.getText());
                    ps.setString(2, txtAutor.getText());
                    ps.setInt(3, Integer.parseInt(txtId.getText()));
                    int filas = ps.executeUpdate();
                    if (filas > 0) {
                        JOptionPane.showMessageDialog(null, "Libro actualizado");
                    } else {
                        JOptionPane.showMessageDialog(null, "Libro no encontrado");
                    }
                    ps.close();
                    con.close();
                    limpiarCampos();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Error al actualizar libro: " + ex.getMessage());
                }
            }
        });

        btnEliminar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Connection con = DriverManager.getConnection(url, user, password);
                    PreparedStatement ps = con.prepareStatement("DELETE FROM Libro WHERE id=?");
                    ps.setInt(1, Integer.parseInt(txtId.getText()));
                    int filas = ps.executeUpdate();
                    if (filas > 0) {
                        JOptionPane.showMessageDialog(null, "Libro eliminado");
                    } else {
                        JOptionPane.showMessageDialog(null, "Libro no encontrado");
                    }
                    ps.close();
                    con.close();
                    limpiarCampos();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Error al eliminar libro: " + ex.getMessage());
                }
            }
        });
    }

    private void limpiarCampos() {
        txtId.setText("");
        txtTitulo.setText("");
        txtAutor.setText("");
    }

    public static void main(String[] args) {
        try {
            // Cargar driver MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "No se encontró el driver MySQL");
            System.exit(1);
        }
        new BibliotecaSpaghettiMySQL().setVisible(true);
    }
}
